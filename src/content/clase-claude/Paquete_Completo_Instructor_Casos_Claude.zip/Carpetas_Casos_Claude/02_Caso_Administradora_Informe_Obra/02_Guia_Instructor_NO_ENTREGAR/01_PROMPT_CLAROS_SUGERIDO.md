# Prompt sugerido - caso administradora

## Contexto
Actúa como analista de control de proyectos para una empresa de arquitectura y diseño. Debes preparar un informe ejecutivo de obra para revisión de la gerente.

## Logro esperado
Construye una visión reconciliada del avance físico, financiero, contractual y de riesgos al 13 de abril de 2026.

## Archivos o datos
Usa únicamente los archivos de esta carpeta. Primero inventaría los documentos, identifica versiones, duplicados y fuentes de control.

## Ruta de trabajo
1. Identifica presupuesto inicial, cambios aprobados, cambios pendientes y costo proyectado.
2. Separa pagos, cuentas causadas, compromisos y proyecciones.
3. Compara avance planificado, reportado por contratista y medido por interventoría.
4. Analiza ruta crítica y fecha final proyectada.
5. Relaciona no conformidades con avance y pagos.
6. Detecta duplicados y cifras no reconciliadas.
7. Define las decisiones que requiere gerencia, responsable y fecha límite.
8. Propón un plan de recuperación de 15 días.

## Output
Entrega: (a) resumen ejecutivo de una página, (b) tablero de indicadores, (c) análisis de variaciones, (d) decisiones requeridas, (e) plan de 15 días y (f) anexos de conciliación.

## Salvaguardas
- No mezcles presupuesto aprobado con cambios pendientes.
- No trates facturas, compromisos y pagos como la misma cifra.
- No uses el reporte comercial de 62% como fuente de avance.
- Señala toda cifra no reconciliada.
- No inventes datos faltantes; formula preguntas o supuestos explícitos.
